text

Game Speed Run � Vers�o Beta / Prot�tipo (em desenvolvimento)

Game Speed Run � um jogo de corrida infinita: a pista rola e os
obst�culos descem em sequ�ncia. O objetivo � sobreviver o m�ximo que
conseguir, desviando dos obst�culos e mantendo o ritmo.

CONTROLES
- Setas: movimentar o personagem.
- Enter: selecionar / entrar na fase.
- Space: Pulo.


COMO JOGAR
1. Extraia esta pasta em qualquer lugar do computador.
2. Execute o arquivo .exe (Windows).
3. N�o � necess�rio ter Python instalado.

OBSERVA��ES
- Este � um prot�tipo beta. Novas mec�nicas est�o sendo adicionadas.
- Feedback � muito bem-vindo: coment�rios, bugs e sugest�es ajudam no
  desenvolvimento.

FEEDBACK
Envie coment�rios, bugs ou sugest�es pelo Itch.io ou pelo GitHub:
https://github.com/Prof-Marcos-Barreto/Meus-projetos-Python

Feito em Python.